<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <?php echo $__env->yieldPushContent('styles'); ?>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Blatzzi - <?php echo $__env->yieldContent('titulo'); ?></title>
        <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
        <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>

        <?php echo \Livewire\Livewire::styles(); ?>

    </head>
    <body class=" bg-slate-200">
        <header class="p-5 border-b bg-white shadow">
            <div class="container mx-auto flex justify-between items-center">
                <a href="<?php echo e(route('home')); ?>" class="text-3xl font-black">
                    Blatzzi
                </a>

                <?php if(auth()->guard()->check()): ?>
                    <nav class="flex gap-2 items-center">
                        <a class="flex items-center gap-2 bg-white border p-2 text-gray-600 rounded text-sm uppercase font-bold cursor-pointer" href="<?php echo e(route('posts.create')); ?>">
                    
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                            </svg>
                              
                            
                            PUBLICAR
                            
                        </a>
                        <a class="font-bold text-gray-600 text-sm pr-2" href="<?php echo e(route('posts.index', auth()->user()->username)); ?>">Hola: <span class="font-normal"> <?php echo e(auth()->user()->username); ?></span></a>
                        <form action="<?php echo e(route('logout')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="font-bold uppercase text-gray-600 text-sm" >Cerrar sesión</button>
                        </form>
                    </nav>
                <?php endif; ?>

                <?php if(auth()->guard()->guest()): ?>
                    <nav class="flex gap-2 items-center">
                        <a class="font-bold uppercase text-gray-600 text-sm pr-2" href="<?php echo e(route('login')); ?>">Ingresar</a>
                        <a class="font-bold uppercase text-gray-600 text-sm" href="<?php echo e(route('register')); ?>">Crear Cuenta</a>
                    </nav>
                <?php endif; ?>

            </div>
        </header>
        <main class="container mx-auto mt-10">
            <h2 class="font-black text-center text-3xl mb-10">
                <?php echo $__env->yieldContent('titulo'); ?>
            </h2>
            <?php echo $__env->yieldContent('contenido'); ?>
        </main>
        <footer class="text-center p-5 text-gray-500 font-bold uppercase mt-10" >
            Construido en Blatzzi.com
            <?php echo e(now()->year); ?>

        </footer>
        <?php echo \Livewire\Livewire::scripts(); ?>

    </body>
</html>
<?php /**PATH /var/www/html/resources/views/layouts/app.blade.php ENDPATH**/ ?>